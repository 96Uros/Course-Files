from flask import Flask, render_template, request
import requests
import keys

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get_weather", methods=["POST"])
def get_weather():
    city = request.form.get("city")
    unit = "metric" #oz imerial za F
    api_key = keys.api_key #zamenjaj z okoljsko spremenljivko: ENVIRONMENT VARIABLE
    #cepa zelis dati to da na render pa moram uvoziti knjiznico:
    #import os in api_key spremenljivko zamenjati s api_key = os.environ("API_KEY") api key je vedno naveden na levi strani na render API_KEY desno napisi svoj api  !

    url = "https://api.openweathermap.org/data/2.5/weather?q={0}&units={1}&appid={2}".format(city, unit, api_key)

    data = requests.get(url=url) 
    print(data.json()) #če zelis kaj novega dodati v kodo.

    return render_template("index.html", data=data.json()) #data=data.json smo poslali v index


if __name__ == "__main__":
    app.run()