
#odpiramo datoteko ki smo ji generirali na zacetki in jo potem prebrali z "r"
with open("test.txt", "r") as test_file:
    content = test_file.read()
    print(content)





#odpiramo novo text datoteko v katero bomo nekaj zapisali
with open("test2.txt", "w") as test2_file:
    test2_file.write("Hello, new file!")

#tukaj se bomo oprebrali text iz test2.txt
with open("test2.txt", "r") as test2_read:
    content2 = test2_read.read()
    print(content2)


