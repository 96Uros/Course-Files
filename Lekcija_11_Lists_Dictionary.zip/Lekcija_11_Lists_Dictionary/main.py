# #to ni več variable ampak LIST!.
# cities = ["Ptuj","Maribor","Izola", "Koper", "Portorož"]

# #dodali smo Ljubljano v seznam cities.
# cities.append("Ljubljana")   #STB!
# print(cities)

# #izbrisali smo zadnjo vrednost na koncu Ljubljana ki smo jo dodali zgoraj
# cities.pop()
# print(cities)

# #Lahko odstranis tudi nekatere med njimi npr: Izola navedeš kateri je po vrsti in ga odstraniš IDEX se začne z 0!!!!
# cities.pop(2)
# print(cities)



numbers = [12, 32, 44, 100, 3211, 7844, 14566, 45627, 1, 22, 88]

numbers.sort() #Sortiramo stevila od najmansega do navecjega.

for number in numbers:
    if number % 2 == 0:  #če je pri deljenju tega števila z 2 ostanek 0 potem je to sodo
        print(number)
    



