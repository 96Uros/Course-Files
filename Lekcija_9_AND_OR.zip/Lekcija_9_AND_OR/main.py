"""

age = int(input("Enter your age: "))

if age > 12 and age < 20:
    print("You are a teenager!")

print("END")

"""

name = input("Enter your name: ")
if name == "Uroš" or name == "uroš" or name == "UROŠ":
    print("Hello Uroš.")
