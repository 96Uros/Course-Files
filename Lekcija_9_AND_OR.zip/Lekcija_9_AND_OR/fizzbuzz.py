
print("Welcome to the FizzBuzz game!")

number = int(input("Enter your number between 1 and 100: "))

# Modulo operator "%" izračuna vedno ostanek od deljenja
# 20 % 6 = 2
# 20 % 7 = 6
# 20 % 5 = 0
# 14 % 3 = 2
#  5 % 5 = 0

for x in range(1,number + 1):
    if x % 3 == 0 and x % 5 == 0:
        print("FizzBuzz")
    elif x % 3 == 0:
        print("Fizz")
    elif x % 5 == 0:
        print("Buzz")
    else:
        print(x)