# 1 eur = 239.64 Tolarjev

tolar = 239.64

print("Zdravo, to je pretvornik valute EUR v Tolarje!")

while True:
    eur = float(input("Vnesi število [€]: "))   
    pretvorba = eur * tolar
    print(f"{eur} = {pretvorba} SIT!")


    izbira = input("Ali želiš nadaljevati (Da/Ne) ? ").lower() #upošteva male črke
    if izbira != "Da" and izbira != "da":
        break
    