import random

secret = random.randint(1,21)

attempts = 0


#prebrali bomo best score iz txt datoteke
with open("record.txt", "r") as record_file:
    best_score = int(record_file.read())
    print(f"Current best score is: {best_score}.")

#While loop - zanka

while True: 
    guess = int(input("Enter your guess (between 1 and 20): "))
    attempts += 1 #prišteva vrednost je enako kot attempts = attempts + 1 best_score

    if guess == secret:
        print("Great you did it!")
        print(f"{attempts} attempt/s needed.")

        if attempts < best_score:
            with open("record.txt", "w") as record_file: #tuakj bomo zapisali poskuse
                 record_file.write(str(attempts))

        break
    elif guess < secret:
        print("Higher!")
    elif guess > secret:
        print("Lower!")
    else:
        print("Try again...")




#For loop - zanka
#določili smo 5 poskusov za igro for x in range(5):
"""
for x in range(5):
    guess = int(input("Enter your guess (between 1 and 20): "))

    if guess == secret:
        print("Great you did it!")
        break
    else:
        print("Try again...")
"""
