from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/calculate", methods = ["POST"])
def calculate():
    euros = float(request.form.get("euros"))
    sit = 239.64 * euros

    
    return render_template("result.html", euros = euros, sit = sit)

if __name__ == "__main__":
    app.run()
