#makeresponse je za piskotke!
from flask import Flask, render_template, request, make_response
from flask_sqlalchemy import SQLAlchemy
import hashlib #za šifriranje!
import uuid #to je knjižnica za generiranje ključnih nizov


app = Flask(__name__)

#to je vedno enako lahko kopiraš za baze podatkov!
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///users.db"
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String)
    password = db.Column(db.String)
    session_token = db.Column(db.String) #vedno piši z veliko Column, String, Intiger... 

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["POST", "GET"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        #preden posljem v bazo podatkov moram generirati zeton uuid uuid4 je dolg varen niz
        session_token = str(uuid.uuid4())

        user = User(username=username, password=hashed_password, session_token=session_token)
        db.session.add(user)
        db.session.commit()
        #Vključi piškotke pri registraciji
        response = make_response(render_template("mypage.html", username=username))
        response.set_cookie("session_token", session_token)

        return response

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")

    #PREVERJANJE UPORABNIKA
    #iz baze podatkov moramo poiskati userja
    user = User.query.filter_by(username=username).first()
    if not user:
        return render_template("register.html")
    
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
    if hashed_password == user.password:
        response = make_response(render_template("mypage.html", username=username)) #preusmeritev na /mypage URL (HANDLER) domača naloga!
        response.set_cookie("username", username)
        return response
    
    else:
        return render_template("index.html")
    
@app.route("/mypage")
def my_page():
    #preverimo ce obstaja zeton
    session_token = request.cookies.get("session_token")

    user = User.query.filter_by(session_token=session_token).first()
    if not user:
        return render_template("index.html")
    else:
        return render_template("mypage.html", username=user.username)
    


if __name__ == "__main__":

    #to lahko kopiraš za baze podatkov
    with app.app_context():
        db.create_all()

    app.run()