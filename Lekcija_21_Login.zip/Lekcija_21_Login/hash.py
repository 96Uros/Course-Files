#tuakj bomo samo pokazali kako deluje šifriranje!
#nima veze z datoteko maina in pingo logina je samo za rpedstavitev!
import hashlib

password = "John123"
password2 = "john123"

hashed_password = hashlib.sha256(password.encode()).hexdigest()
hashed_password2 = hashlib.sha256(password2.encode()).hexdigest()


#tako lahko preverim da na strani pod register da uproabnim vnese prava gesla za registracijo
if hashed_password == hashed_password2:
    print("Gesli se ujemata")
else:
    print("Napačno geslo, se ne ujemata!")



#po nekem ključu smo spremenili john123 