import datetime
import random
import json

def play_game(level):
    secret = random.randint(1, 30)
    attempts = 0
    score_list = get_score_list()

    while True:
        guess = int(input("Guess the number between 1 and 30: "))
        attempts += 1

        if guess == secret:
            print(f"Congrats! {attempts} needed.")
            current_time = datetime.datetime.now()
            score_list.append({"attempts": attempts, "date": current_time.isoformat()})
            with open("score_list.json", "w") as score_file:
                score_file.write(json.dumps(score_list))
            break
        elif guess > secret and level=="easy":
            print("Try something lower.")
        elif guess < secret and level=="easy":
            print("Try something higher.")
        else:
            print("Your guess is not correct!")

def get_score_list():
    with open("score_list.json", "r") as score_file:
        score_list = json.loads(score_file.read())
        return score_list
    
def get_top_scores():
    score_list = get_score_list()
    top_score_list = sorted(score_list, key=lambda k: k["attempts"])[:3]
    return top_score_list

    
while True:
    select = input("Would you like to A) play a new game, B) see the best scores, or C) quit? ")

    if select.upper() == "A":
        level = input("Choose your level (easy/hard): ")
        play_game(level)
    elif select.upper() == "B":
        for score_dict in get_top_scores():
            print(str(score_dict["attempts"]) + " attempts, date: " + score_dict["date"])
    else:
        break