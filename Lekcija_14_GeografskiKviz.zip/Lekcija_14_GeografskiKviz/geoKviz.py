import random


#za kombinacijo mest uporabim slovar
countriesCities = {
    "Slovenia": "Ljubljana",
    "Croatia": "Zagreb",
    "Austria": "Vienna",
    "Italy": "Rome",
    "Hungary": "Budapest",
    "Belgium": "Brussels",
    "Bulgaria": "Sofia",
    "Cyprus": "Nicosia",
    "Czech Republic": "Prague",
    "Denmark": "Copenhagen",
    "Estonia": "Tallinn",
    "Finland": "Helsinki",
    "France": "Paris",
    "Germany": "Berlin",
    "Greece": "Athens",
    "Ireland": "Dublin",
    "Latvia": "Riga",
    "Lithuania": "Vilnius",
    "Luxembourg": "Luxembourg City",
    "Malta": "Valletta",
    "Netherlands": "Amsterdam",
    "Poland": "Warsaw",
    "Portugal": "Lisbon",
    "Romania": "Bucharest",
    "Slovakia": "Bratislava",
    "Spain": "Madrid",
    "Sweden": "Stockholm"
}

def startQuiz():  # nakljucno izbere in countriesCities
    country = random.choice(list(countriesCities.keys()))
    capital = countriesCities[country]

    print(f"What is the capital city of {country}?")
    answer = input("Answer: ")

    if answer.lower() == capital.lower():
        print("Yes, thats correct!")
    else:
        print(f"No, no thats not correct, capital city of {country} is {capital}.")

    repeat = input("Do you want to continue Yes/No?")
    if repeat.lower() == "yes":
        #Play again
        startQuiz()
    else:
        print("Thanks for playing this game")

startQuiz()
    