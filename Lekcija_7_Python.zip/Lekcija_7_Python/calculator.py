""" 
number1 = 12
number2 = 15.5
number3 = number1 + number2

print(number3)
"""

number1 = float(input("enter number 1: "))
number2 = float(input("enter number 2: "))

operation = input("chose math operation (+,-,*,/) :")

if operation == "+":
    print(number1 + number2)
elif operation == "-":
    print(number1 + number2)
elif operation == "*":
    print(number1 + number2)
elif operation == "/":
    print(number1 + number2)
else:
    print("something went wrong")
