

box = {"heightCm": 20, "widthCm": 45, "lenghtCm": 30}

# #dodajanje v dictionary
# box["weightKg"] = 5
# print(box)

# #sprememba sirine v dictionary
# box["widthCm"] = 25
# print(box)

box.pop("heightCm")
print(box)