
#super class - prenos kode inheritance
class player():
    def __init__(self, firstName, lastName, heightCm, weightKg):
        self.firstName = firstName
        self.lastName = lastName
        self.heightCm = heightCm
        self.weightKg = weightKg

    #znotraj classa lahko delamo funkcije
    def weightToLbs(self):
        pounds = round(self.weightKg * 2.2, 2)
        return pounds

#model
class basketBallPlayers(player):
    #konstruktor
    def __init__(self, firstName, lastName, heightCm, weightKg, points, rebounds, assists):
        super().__init__(firstName=firstName, lastName=lastName, heightCm=heightCm, weightKg=weightKg)
        self.points = points
        self.rebounds = rebounds
        self.assists = assists


class footBallPlayer(player):
    def __init__(self, firstName, lastName, heightCm, weightKg, goals, yellowCards, redCards):
        super().__init__(firstName=firstName, lastName=lastName, heightCm=heightCm, weightKg=weightKg)
        self.goals = goals
        self.yellowCards = yellowCards
        self.redCards = redCards

messi = footBallPlayer("leo", "Messi", 170, 67, 575, 67, 0)
oblak = footBallPlayer("Jan", "Oblak", 278, 74, 1, 5, 0)

print(f"Oblak ima {oblak.redCards} rdecih kartonov")
print(messi.lastName)




#####DN 13.1
