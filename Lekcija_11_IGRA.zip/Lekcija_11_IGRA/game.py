import random
import json
import datetime #vnosi datumov in ure vrstica 9

secret = random.randint(1,21)
attempts = 0

#username on start
name = input("Input your name: ")

#dodaj izpis podatkov lepse oblike na zacetku in dodaj vpisane stevilke az poskuse

#zapis časa
currentTime = datetime.datetime.now()


#tuakj odpremo json
with open("scorelist.json", "r") as score_file:
    score_list = json.loads(score_file.read())
    print("Top score: " + str(score_list)) 


#While loop - zanka
while True: 
    guess = int(input("Enter your guess (between 1 and 20): "))
    attempts += 1

    if guess == secret:
        print("Congrats, you won!")
        print(f"{attempts} attempt/s needed.")

        score_list.append({"Attempts": attempts, "Time": currentTime.isoformat(), "Name": name, "SecretNumber": secret})

        with open("scorelist.json", "w") as score_file:
            score_file.write(json.dumps(score_list)) #dumps zapise v json

        break
    elif guess < secret:
        print("Higher!")
    elif guess > secret:
        print("Lower!")
    else:
        print("Try again...")
