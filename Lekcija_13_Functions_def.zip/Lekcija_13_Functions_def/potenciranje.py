def get_num(number):
    print(number*number)
    print(number*number*number)
    print(number*number*number*number*number)
    print(number*number*number*number*number*number*number*number)

get_num(2)


