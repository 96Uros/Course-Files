def stevecKorakov(razdaljaMetri, dolzinaKorakaMetri):
    return int(razdaljaMetri / dolzinaKorakaMetri)

steviloKorakov = stevecKorakov(5000, 0.8) #korakov, dolzina koraka 0.8m
print(steviloKorakov)

