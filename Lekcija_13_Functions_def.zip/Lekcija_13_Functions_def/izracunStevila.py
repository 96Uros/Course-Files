
def sestevanje(prvi, drugi):
    rezultat = prvi + drugi
    return rezultat

vsota = sestevanje(5, 55)
print(vsota)
