def absolute_difference(number1, number2):
    if number1 > number2:
        return number1 - number2
    else:
        return number2 - number1

print(absolute_difference(number1 = 20, number2 = 10))
print(absolute_difference(number1 = 5, number2 = 15))
print(absolute_difference(number1 = -20, number2 = 10))
print(absolute_difference(number1 = 20, number2 = -20))
