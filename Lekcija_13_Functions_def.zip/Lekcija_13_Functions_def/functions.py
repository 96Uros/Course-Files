# def say_hello(name, age, city):
#     print(f"Hello, {name} you are from {city} & {age} years old. Am I right?")
# say_hello(name = "Uroš", age = 28, city = "Ptuj")
# say_hello(name = "Erik", age = 4, city = "Ptuj")



#ko imas return moras narediti spremenljivko.
def say_hello(name, city):
    return "Hello {0} from {1}!".format(name, city)
message = say_hello(name = "Špela", city = "Ptuj")
print(message)

# lahko tudi zapisem samo:
print(say_hello(name = "Špela", city = "Ptuj"))